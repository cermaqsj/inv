/**
 * CONFIGURATION
 */
const CONFIG = {
    // Default API URL from user
    DEFAULT_API: 'https://script.google.com/macros/s/AKfycbzpgUkMhdDmLSaejzg_Faql7j-fpojIx0mx98w1sQzl9Wdbfjx1YRdVZij9VLnF5sCK/exec',
    STORAGE_KEY: 'cermaq_inventory_url',
};

let html5QrcodeScanner = null;
let currentProduct = null;
let isScanning = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

function initApp() {
    checkConnection();

    // Setup event listeners
    document.getElementById('btn-scan-start').addEventListener('click', startScanner);

    // Close modal on click outside (optional or keep simple)
    document.querySelector('.modal-backdrop').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) closeModal();
    });
}

/**
 * API HANDLING
 */
function getApiUrl() {
    return localStorage.getItem(CONFIG.STORAGE_KEY) || CONFIG.DEFAULT_API;
}

async function checkConnection() {
    updateStatus('connecting', 'Conectando...');
    try {
        const response = await fetch(getApiUrl());
        if (!response.ok) throw new Error("API Error");

        const data = await response.json();
        updateStatus('online', `Conectado (${data.length} productos)`);
        return true;
    } catch (error) {
        console.error(error);
        updateStatus('offline', 'Sin conexión');
        return false;
    }
}

async function fetchProduct(id) {
    showToast('Buscando producto...', 'info');
    try {
        const response = await fetch(getApiUrl());
        const data = await response.json();
        return data.find(p => String(p.id) === String(id));
    } catch (e) {
        showToast('Error de conexión', 'error');
        return null;
    }
}

async function sendTransaction(payload) {
    try {
        // IMPORTANT: We use standard CORS now, assuming standard setup.
        // If Google Script needs it, we can use 'no-cors' but we prefer response reading.
        // For best results with Google Apps Script Web App, use:
        // ContentService.createTextOutput(...).setMimeType(ContentService.MimeType.JSON);

        const response = await fetch(getApiUrl(), {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        // Google Apps Script redirects on success usually, catch that if possible
        const result = await response.json();
        return result;
    } catch (error) {
        // Fallback for opaque responses if CORS is tricky
        console.error("Transacción error:", error);
        throw error;
    }
}

/**
 * UI LOGIC
 */
function updateStatus(state, text) {
    const dot = document.getElementById('status-dot');
    const label = document.getElementById('status-text');

    dot.className = 'dot'; // reset
    if (state === 'online') dot.classList.add('online');
    else if (state === 'error') dot.classList.add('error');

    label.innerText = text;
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'info';
    if (type === 'success') icon = 'check_circle';
    if (type === 'error') icon = 'error';

    toast.innerHTML = `
        <span class="material-icons-round">${icon}</span>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    // Remove after 3s
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.addEventListener('transitionend', () => toast.remove());
    }, 3000);
}

/**
 * SCANNER LOGIC
 */
function startScanner() {
    if (isScanning) return;

    document.querySelector('.scanner-wrapper').classList.add('active');
    document.querySelector('.scan-overlay').style.opacity = '0';
    document.getElementById('btn-scan-text').innerText = 'Escanear...';

    html5QrcodeScanner = new Html5Qrcode("reader");
    html5QrcodeScanner.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        onScanSuccess
    ).catch(err => {
        showToast("Error cámara: " + err, 'error');
    });

    isScanning = true;
}

function stopScanner() {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.stop().then(() => {
            html5QrcodeScanner.clear();
            isScanning = false;
            document.querySelector('.scan-overlay').style.opacity = '1';
            document.getElementById('btn-scan-text').innerText = 'ESCANEAR';
        });
    }
}

let cart = [];

/**
 * CART SYSTEM
 */
function addToCart(type) {
    if (!currentProduct) return;

    const qty = parseInt(document.getElementById('qty-input').value);
    const id = currentProduct.id;
    const name = currentProduct.nombre;

    if (type === 'OUT') {
        const currentStock = parseInt(currentProduct.stock);
        if (qty > currentStock) {
            showToast(`Error: Stock insuficiente. Tienes ${currentStock}`, 'error');
            return;
        }
    }

    // Add to local state
    cart.push({
        id: id,
        name: name,
        type: type,
        qty: qty,
        timestamp: new Date()
    });

    updateCartBadge();
    closeModal();
    showToast(`${type === 'IN' ? 'Ingreso' : 'Salida'} agregado a la lista`, 'success');

    // Resume scanning immediately if camera was open
    // We don't close the scanner, so user can keep going.
}

function updateCartBadge() {
    const badge = document.getElementById('cart-badge');
    badge.innerText = cart.length;
    badge.style.display = cart.length > 0 ? 'block' : 'none';
}

function openCartModal() {
    document.getElementById('modal-cart').classList.add('active');
    renderCart();
}

function renderCart() {
    const container = document.getElementById('cart-items-container');
    container.innerHTML = '';

    if (cart.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 2rem; color: var(--text-light);">Tu lista está vacía.</div>';
        return;
    }

    cart.forEach((item, index) => {
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `
            <div class="cart-item-info">
                <h4>${item.name}</h4>
                <p>ID: ${item.id} | Cantidad: <b>${item.qty}</b></p>
            </div>
            <div class="cart-item-action">
                <span class="tag ${item.type === 'IN' ? 'in' : 'out'}">${item.type}</span>
                <button class="icon-btn" onclick="removeFromCart(${index})">
                    <span class="material-icons-round" style="color: var(--danger)">delete</span>
                </button>
            </div>
        `;
        container.appendChild(div);
    });
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartBadge();
    renderCart();
}

async function processCart() {
    if (cart.length === 0) return;

    const btn = document.querySelector('#modal-cart .btn-primary');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons-round spin">sync</span> Procesando...';
    btn.disabled = true;

    let successCount = 0;
    let errors = [];

    // Process sequentially to avoid race conditions on the Sheet
    for (const item of cart) {
        try {
            const result = await sendTransaction({
                action: item.type,
                id: item.id,
                quantity: item.qty,
                user: "WebUser" // Could be dynamic
            });

            if (result.status === 'success') {
                successCount++;
            } else {
                errors.push(`${item.name}: ${result.message}`);
            }
        } catch (e) {
            errors.push(`${item.name}: Error de red`);
        }
    }

    // Done
    btn.innerHTML = originalText;
    btn.disabled = false;

    if (errors.length === 0) {
        showToast(`¡Éxito! ${successCount} movimientos procesados.`, 'success');
        cart = [];
        updateCartBadge();
        closeModal();
        checkConnection(); // Refresh global stock
    } else {
        alert(`Se procesaron ${successCount} ítems correctament, pero hubo errores:\n\n${errors.join('\n')}`);
        // Remove successful ones? For now, we keep cart for retry or manual clear
        // Ideally we filter out the successful ones from 'cart' here.
    }
}

// Replaces the old direct handleTransaction
function handleTransaction(type) {
    addToCart(type);
}

// Updated Scan Success with Vibration
function onScanSuccess(decodedText) {
    // Vibrate for feedback
    if (navigator.vibrate) navigator.vibrate(200);

    // Play sound if needed (User requested vibration only, so commented out)
    // const audio = new Audio('beep.mp3'); audio.play();

    stopScanner(); // Consider keeping it open for "Continuous Mode" later
    openProductModal(decodedText);
}

async function handleCreate() {
    const id = document.getElementById('new-id').value;
    const name = document.getElementById('new-name').value;
    const stock = document.getElementById('new-stock').value;

    if (!id || !name) {
        showToast('Faltan datos obligatorios', 'error');
        return;
    }

    closeModal();
    showToast('Creando producto...', 'info');

    try {
        const result = await sendTransaction({
            action: 'ADD',
            id: id,
            nombre: name,
            stock: stock,
            user: "WebAdmin"
        });

        if (result.status === 'success') {
            showToast('Producto creado correctamente', 'success');
            checkConnection();
        } else {
            showToast('Error: ' + result.message, 'error');
        }
    } catch (e) {
        showToast('Error al crear producto', 'error');
    }
}

/**
 * LABEL MAKER LOGIC
 */
async function openLabelMaker() {
    document.getElementById('modal-labels').classList.add('active');
    const container = document.getElementById('label-container');
    container.innerHTML = '<div style="text-align: center; color: #94a3b8; grid-column: 1/-1;">Cargando inventario...</div>';

    try {
        const response = await fetch(getApiUrl());
        const products = await response.json();

        container.innerHTML = ''; // clear loading

        if (products.length === 0) {
            container.innerHTML = '<div style="text-align: center;">No hay productos.</div>';
            return;
        }

        products.forEach(p => {
            // Create Card
            const card = document.createElement('div');
            card.className = 'qr-label';

            // Generate content
            // We use a container for the QR to append it safely
            const qrContainer = document.createElement('div');
            qrContainer.className = 'qr-code-img';

            card.innerHTML = `
                <h3>${p.nombre}</h3>
            `;
            card.appendChild(qrContainer);
            card.innerHTML += `
                <div class="qr-id">ID: ${p.id}</div>
            `;

            // Generate QR using LOCAL IMAGE (100% Print Reliability)
            const img = document.createElement('img');
            // Points to the folder we just populated with the script
            img.src = `qr_codes/${p.id}.png`;
            img.alt = `QR ${p.id}`;
            img.style.width = "100%";
            img.style.height = "auto";
            img.style.display = "block";

            // Fallback just in case script wasn't run for a specific ID
            img.onerror = function () {
                this.onerror = null; // prevent infinite loop
                // Dynamic fallback to QuickChart just like the Node script
                this.src = `https://quickchart.io/qr?text=${p.id}&size=300&dark=000000&light=ffffff&margin=1`;
                this.style.opacity = "1";
            };

            qrContainer.appendChild(img);
            container.appendChild(card);
        });

    } catch (e) {
        console.error(e); // Helper for debugging
        container.innerHTML = '<div style="text-align: center; color: var(--danger);">Error al cargar productos.</div>';
        showToast('Error cargando inventario', 'error');
    }
}


function printLabels() {
    // Local images print instantly and reliably.
    window.print();
}

/**
 * MISSING FUNCTIONS IMPLEMENTATION
 */

function closeModal() {
    document.querySelectorAll('.modal-backdrop').forEach(modal => {
        modal.classList.remove('active');
    });
    // Reset inputs
    document.getElementById('qty-input').value = 1;
    document.getElementById('new-id').value = '';
    document.getElementById('new-name').value = '';
    document.getElementById('new-stock').value = 0;
}

function openCreateModal() {
    document.getElementById('modal-create').classList.add('active');
}

async function manualInput() {
    const input = prompt("Ingresa el ID del producto manualmente:");
    if (input) {
        // Stop scanner if active to avoid conflicts
        if (isScanning) stopScanner();

        // Open product modal
        await openProductModal(input);
    }
}

function adjustQty(amount) {
    const input = document.getElementById('qty-input');
    let currentValue = parseInt(input.value) || 1;
    let newValue = currentValue + amount;

    // Minimo 1
    if (newValue < 1) newValue = 1;

    input.value = newValue;
}

async function openProductModal(idOrData) {
    // Determine if we have an ID string or object
    let product;

    // Check local lookup first
    if (typeof idOrData === 'string') {
        product = await fetchProduct(idOrData);
    } else {
        product = idOrData;
    }

    if (!product) {
        const create = confirm(`El producto ID ${idOrData} no existe. ¿Quieres crearlo?`);
        if (create) {
            document.getElementById('new-id').value = idOrData;
            openCreateModal();
        }
        return;
    }

    // Set Global
    currentProduct = product;

    // UI
    document.getElementById('p-name').innerText = product.nombre;
    document.getElementById('p-id').innerText = product.id;
    document.getElementById('p-stock').innerText = product.stock;

    // Reset Qty
    document.getElementById('qty-input').value = 1;

    document.getElementById('modal-product').classList.add('active');
}
